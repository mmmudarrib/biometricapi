const { Sequelize } = require('sequelize');

const db = new Sequelize('nodejspravctice', 'root', '28071998', {
  host: 'localhost',
  dialect: 'mysql',
});

module.exports = db;
