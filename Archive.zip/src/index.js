// src/index.js
const express = require('express');
const db = require('./config/database');
// Connect to the database
db.authenticate()
  .then(() => console.log('Database connected'))
  .catch((err) => console.error('Error connecting to database:', err));

// Sync models with the database
const User = require('./models/user');
const Device = require('./models/device');
const Attendance = require('./models/attendance');

// Set up express app
const app = express();
app.use(express.json());
db.sync()
  .then(() => {
    console.log('Tables created successfully.');
  })
  .catch((err) => {
    console.error('Error creating tables:', err);
  });
// Routes
app.use('/users', require('./routes/user'));
app.use('/attendance', require('./routes/attendance'));
app.use('/device', require('./routes/device'));

// This will sync all defined models and create the tables if they don't exist
// It's not recommended for production environments.

// Start the server
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Server started on port ${PORT}`);
});
