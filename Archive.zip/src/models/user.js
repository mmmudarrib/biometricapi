// src/models/user.js
const { DataTypes } = require('sequelize');
const db = require('../config/database');


const User = db.define('User', {
  name: {
    type: DataTypes.STRING,
    allowNull: false,
  },
  fingerprintTemplate: {
    type: DataTypes.TEXT,
    allowNull: false,
  },
});module.exports = User;
