// src/models/device.js
const { DataTypes } = require('sequelize');
const db = require('../config/database');

const Device = db.define('Device', {
  name: {
    type: DataTypes.STRING,
    allowNull: false,
  },
  address: {
    type: DataTypes.STRING,
    allowNull: false,
  },
});
module.exports = Device;
