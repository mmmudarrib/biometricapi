'use strict';
const {
  Model
} = require('sequelize');
module.exports = (sequelize, DataTypes) => {
  class Attendance extends Model {
    /**
     * Helper method for defining associations.
     * This method is not a part of Sequelize lifecycle.
     * The `models/index` file will call this method automatically.
     */
  }
  Attendance.init({
    title: DataTypes.STRING(255),
    content: DataTypes.TEXT,
    authorId: DataTypes.INTEGER,
    isDeleted: DataTypes.BOOLEAN,
}, {
    sequelize,
    modelName: 'attendance',
  });
  return Blog;
};