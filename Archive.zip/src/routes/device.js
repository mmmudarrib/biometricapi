// src/routes/device.js
const express = require('express');
const router = express.Router();
const { Device } = require('../models/device');

// Get all devices
router.get('/', async (req, res) => {
  try {
    const devices = await Device.findAll();
    res.json(devices);
  } catch (err) {
    console.error('Error fetching devices:', err);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Create a new device
router.post('/', async (req, res) => {
  try {
    const { name, address } = req.body;
    const newDevice = await Device.create({ name, address });
    res.status(201).json(newDevice);
  } catch (err) {
    console.error('Error creating device:', err);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Update a device
router.put('/:id', async (req, res) => {
  try {
    const { name, address } = req.body;
    const { id } = req.params;
    const [rowsUpdated, [updatedDevice]] = await Device.update(
      { name, address },
      { where: { id }, returning: true }
    );
    if (rowsUpdated === 0) {
      return res.status(404).json({ error: 'Device not found' });
    }
    res.json(updatedDevice);
  } catch (err) {
    console.error('Error updating device:', err);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Delete a device
router.delete('/:id', async (req, res) => {
  try {
    const { id } = req.params;
    const deletedRows = await Device.destroy({ where: { id } });
    if (deletedRows === 0) {
      return res.status(404).json({ error: 'Device not found' });
    }
    res.sendStatus(204);
  } catch (err) {
    console.error('Error deleting device:', err);
    res.status(500).json({ error: 'Internal server error' });
  }
});

module.exports = router;
