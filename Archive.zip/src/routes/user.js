// src/routes/user.js
const express = require('express');
const router = express.Router();
const { User } = require('../models/user');

// Get all users
router.get('/', async (req, res) => {
  try {
    const users = await User.findAll();
    res.json(users);
  } catch (err) {
    console.error('Error fetching users:', err);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Create a new user
router.post('/', async (req, res) => {
  try {
    const { name, fingerprintTemplate } = req.body;
    const newUser = await User.create({ name, fingerprintTemplate });
    res.status(201).json(newUser);
  } catch (err) {
    console.error('Error creating user:', err);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Update a user
router.put('/:id', async (req, res) => {
  try {
    const { name, fingerprintTemplate } = req.body;
    const { id } = req.params;
    const [rowsUpdated, [updatedUser]] = await User.update(
      { name, fingerprintTemplate },
      { where: { id }, returning: true }
    );
    if (rowsUpdated === 0) {
      return res.status(404).json({ error: 'User not found' });
    }
    res.json(updatedUser);
  } catch (err) {
    console.error('Error updating user:', err);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Delete a user
router.delete('/:id', async (req, res) => {
  try {
    const { id } = req.params;
    const deletedRows = await User.destroy({ where: { id } });
    if (deletedRows === 0) {
      return res.status(404).json({ error: 'User not found' });
    }
    res.sendStatus(204);
  } catch (err) {
    console.error('Error deleting user:', err);
    res.status(500).json({ error: 'Internal server error' });
  }
});

module.exports = router;
