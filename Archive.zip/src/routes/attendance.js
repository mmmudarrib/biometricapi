// src/routes/attendance.js
const express = require('express');
const router = express.Router();
const { Attendance } = require('../models/attendance');

// Get all attendance records
router.get('/', async (req, res) => {
  try {
    const attendanceRecords = await Attendance.f({
        attributes: {
            exclude: _exclude
        },});
    res.json(attendanceRecords);
  } catch (err) {
    console.error('Error fetching attendance records:', err);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Create a new attendance record
router.post('/', async (req, res) => {
  try {
    const { date, inOut, userId, deviceId } = req.body;
    const newAttendance = await Attendance.create({ date, inOut, userId, deviceId });
    res.status(201).json(newAttendance);
  } catch (err) {
    console.error('Error creating attendance record:', err);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Update an attendance record
router.put('/:id', async (req, res) => {
  try {
    const { date, inOut, userId, deviceId } = req.body;
    const { id } = req.params;
    const [rowsUpdated, [updatedAttendance]] = await Attendance.update(
      { date, inOut, userId, deviceId },
      { where: { id }, returning: true }
    );
    if (rowsUpdated === 0) {
      return res.status(404).json({ error: 'Attendance record not found' });
    }
    res.json(updatedAttendance);
  } catch (err) {
    console.error('Error updating attendance record:', err);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Delete an attendance record
router.delete('/:id', async (req, res) => {
  try {
    const { id } = req.params;
    const deletedRows = await Attendance.destroy({ where: { id } });
    if (deletedRows === 0) {
      return res.status(404).json({ error: 'Attendance record not found' });
    }
    res.sendStatus(204);
  } catch (err) {
    console.error('Error deleting attendance record:', err);
    res.status(500).json({ error: 'Internal server error' });
  }
});

module.exports = router;
